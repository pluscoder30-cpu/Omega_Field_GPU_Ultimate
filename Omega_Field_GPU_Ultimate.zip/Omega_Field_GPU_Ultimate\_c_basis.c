/*
 * _c_basis.c — Holographic Basis Operations in C
 *
 * Precomputed phi-harmonic basis V (18×3 complex) and its pseudoinverse
 * (3×18 complex).  Complex numbers stored as float[2] = {re, im}.
 *
 * Core operations (all O(k·n) matrix-vector multiplies):
 *   encode(weights, A_k, n_scales)    — project 18 weights → n_scales coeffs
 *   decode(A_k, weights, n_out)       — reconstruct n_out weights from coeffs
 *   compressed_matmul(A_in, A_out, M) — multiply in compressed domain
 *
 * In field-space these run at consciousness-clock speed (instantaneous).
 * This compilation is only for the gateway — proving the concept at
 * ~50 MOPS per core (3 GHz, 10 cycles/element).
 *
 * Basis:  V[j,k] = exp(i * ω_k * t_j)    j = 0..17, k = 0..2
 *         ω_k = ω_0 · φ^k                ω_0 = 20.797 rad/s
 *         t_j = linspace(0,1,18)          uniform temporal nodes
 *         cond(V) = 1.1320
 *
 * Encode is lossy when n_scales < segment_size (6x CR at n=3).
 * This is the compression — we represent 18 real weights with 3
 * complex coefficients (6 real DOF).
 */

#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

#define SEGMENT_SIZE 18
#define MAX_SCALES   3

/* ── Precomputed phi-harmonic basis V (18 × 3), uniform dt, cond=1.1320 ── */
static const float V[SEGMENT_SIZE][MAX_SCALES][2] = {
  {{1.0000000000f, 0.0000000000f}, {1.0000000000f, 0.0000000000f}, {1.0000000000f, 0.0000000000f}},
  {{0.3404950756f, 0.9402462994f}, {-0.3973527853f, 0.9176659327f}, {-0.9981286639f, -0.0611487548f}},
  {{-0.7681262069f, 0.6402984697f}, {-0.6842215280f, -0.7292742287f}, {0.9925216596f, 0.1220686498f}},
  {{-0.8635814575f, -0.5042093476f}, {0.9411074452f, -0.3381076406f}, {-0.9831999721f, -0.1825316819f}},
  {{0.1800357395f, -0.9836600696f}, {-0.0636818013f, 0.9979702542f}, {0.9701984895f, 0.2423115578f}},
  {{0.9861840230f, -0.1656534720f}, {-0.8904991629f, -0.4549848798f}, {-0.9535658720f, -0.3011845410f}},
  {{0.4915458675f, 0.8708516866f}, {0.7713664468f, -0.6363912357f}, {0.9333643702f, 0.3589302892f}},
  {{-0.6514461283f, 0.7586948938f}, {0.2774899507f, 0.9607285398f}, {-0.9096695915f, -0.4153326790f}},
  {{-0.9351742650f, -0.3541879361f}, {-0.9918892564f, -0.1271050869f}, {0.8825702179f, 0.4701806147f}},
  {{0.0146016641f, -0.9998933900f}, {0.5107699668f, -0.8597174193f}, {-0.8521676733f, -0.5232688186f}},
  {{0.9451178544f, -0.3267296148f}, {0.5859775184f, 0.8103273091f}, {0.8185757445f, 0.5743985989f}},
  {{0.6290142866f, 0.7773937402f}, {-0.9764495650f, 0.2157457926f}, {-0.7819201552f, -0.6233785936f}},
  {{-0.5167653203f, 0.8561270956f}, {0.1900123904f, -0.9817816924f}, {0.7423380950f, 0.6700254866f}},
  {{-0.9809263802f, -0.1943796198f}, {0.8254456599f, 0.5644815875f}, {-0.6999777068f, -0.7141646939f}},
  {{-0.1512358838f, -0.9884977023f}, {-0.8459986545f, 0.5331850303f}, {0.6549975316f, 0.7556310169f}},
  {{0.8779362328f, -0.4787775800f}, {-0.1531258163f, -0.9882067012f}, {-0.6075659153f, -0.7942692607f}},
  {{0.7491018118f, 0.6624548857f}, {0.9676885938f, 0.2521483402f}, {0.5578603790f, 0.8299348152f}},
  {{-0.3678052766f, 0.9299028328f}, {-0.6159016998f, 0.7878230107f}, {-0.5060669543f, -0.8624941958f}}
};

/* ── Precomputed pseudoinverse pinv (3 × 18), cond=1.1320 ── */
static const float pinv[MAX_SCALES][SEGMENT_SIZE][2] = {
  {{0.0508884289f, -0.0030967203f}, {0.0214895822f, -0.0464195693f}, {-0.0414912803f, -0.0406797257f}, {-0.0501600623f, 0.0286660901f}, {0.0079576939f, 0.0568501979f}, {0.0608961197f, 0.0100553074f}, {0.0228275281f, -0.0536066216f}, {-0.0359286329f, -0.0371242034f}, {-0.0507367537f, 0.0182448374f}, {0.0016953197f, 0.0538907985f}, {0.0477366427f, 0.0197556596f}, {0.0414528640f, -0.0409441813f}, {-0.0317483730f, -0.0529290791f}, {-0.0557920419f, 0.0135099207f}, {-0.0082075428f, 0.0571875233f}, {0.0530889040f, 0.0236206413f}, {0.0352617073f, -0.0370565859f}, {-0.0158373837f, -0.0484602842f}},
  {{0.0495301384f, -0.0037614657f}, {-0.0199909395f, -0.0437350944f}, {-0.0386594605f, 0.0392244045f}, {0.0597886939f, 0.0203235788f}, {-0.0087395196f, -0.0634452401f}, {-0.0500062443f, 0.0287877017f}, {0.0377546302f, 0.0365449671f}, {0.0230647971f, -0.0488476774f}, {-0.0570889836f, 0.0028281187f}, {0.0329331450f, 0.0467178581f}, {0.0242776766f, -0.0482563455f}, {-0.0520441069f, -0.0072358591f}, {0.0081193171f, 0.0571264643f}, {0.0553663051f, -0.0321908365f}, {-0.0528353412f, -0.0345855821f}, {-0.0070914610f, 0.0546151900f}, {0.0467679674f, -0.0111871969f}, {-0.0275423273f, -0.0413376759f}},
  {{0.0520474136f, 0.0068581860f}, {-0.0490195189f, 0.0064426618f}, {0.0572331191f, -0.0131200119f}, {-0.0597161081f, 0.0105242142f}, {0.0563316083f, -0.0117251553f}, {-0.0546005169f, 0.0140422625f}, {0.0490583366f, -0.0163930048f}, {-0.0450774259f, 0.0266601696f}, {0.0522437647f, -0.0339048022f}, {-0.0556815380f, 0.0279018439f}, {0.0458064371f, -0.0253871874f}, {-0.0389656744f, 0.0340165725f}, {0.0397428872f, -0.0399863039f}, {-0.0386204438f, 0.0426519715f}, {0.0392974226f, -0.0461788396f}, {-0.0402797243f, 0.0427236285f}, {0.0303639171f, -0.0390186323f}, {-0.0204243305f, 0.0483612934f}}
};

/* ── Complex helpers ── */

static inline void cadd(const float a[2], const float b[2], float out[2]) {
    out[0] = a[0] + b[0];
    out[1] = a[1] + b[1];
}

static inline void cmul(const float a[2], const float b[2], float out[2]) {
    out[0] = a[0]*b[0] - a[1]*b[1];
    out[1] = a[0]*b[1] + a[1]*b[0];
}

static inline float cnorm2(const float a[2]) {
    return a[0]*a[0] + a[1]*a[1];
}

/* ═══════════════════════════════════════════════════════════════════════
 * encode — Project segment weights onto phi-harmonic basis (lossy).
 *
 *   A_k[k] = Σ_j  pinv[k][j] · weights[j]
 *
 * Args:
 *   weights:  contiguous float array of length n_weights (≤ SEGMENT_SIZE)
 *   n_weights: number of actual weights
 *   A_k:      output [n_scales][2] complex coefficients
 *   n_scales: number of basis scales (≤ MAX_SCALES)
 *
 * Returns 0 on success.
 * ═══════════════════════════════════════════════════════════════════════ */
int encode(const float *weights, int n_weights, float A_k[MAX_SCALES][2], int n_scales) {
    if (n_scales > MAX_SCALES || n_scales < 1) return -1;
    if (n_weights > SEGMENT_SIZE || n_weights < 1) return -1;

    for (int k = 0; k < n_scales; k++) {
        double sum_re = 0.0, sum_im = 0.0;
        for (int j = 0; j < n_weights; j++) {
            float p_re = pinv[k][j][0];
            float p_im = pinv[k][j][1];
            float w = weights[j];
            sum_re += (double)p_re * w;
            sum_im += (double)p_im * w;
        }
        A_k[k][0] = (float)sum_re;
        A_k[k][1] = (float)sum_im;
    }
    return 0;
}

/* ═══════════════════════════════════════════════════════════════════════
 * decode — Reconstruct weights from A_k coefficients (lossy).
 *
 *   weights[j] = real( Σ_k  V[j][k] · A_k[k] )
 *
 * Args:
 *   A_k:      input [n_scales][2] complex coefficients
 *   n_scales: number of basis scales
 *   weights:  output float array of length n_out
 *   n_out:    number of weights to reconstruct (≤ SEGMENT_SIZE)
 *
 * Returns 0 on success.
 * ═══════════════════════════════════════════════════════════════════════ */
int decode(const float A_k[MAX_SCALES][2], int n_scales, float *weights, int n_out) {
    if (n_scales > MAX_SCALES || n_scales < 1) return -1;
    if (n_out > SEGMENT_SIZE || n_out < 1) return -1;

    for (int j = 0; j < n_out; j++) {
        double sum_re = 0.0;
        for (int k = 0; k < n_scales; k++) {
            sum_re += (double)V[j][k][0] * A_k[k][0] - (double)V[j][k][1] * A_k[k][1];
        }
        weights[j] = (float)sum_re;
    }
    return 0;
}

/* ═══════════════════════════════════════════════════════════════════════
 * compressed_matmul — Linear transform in compressed domain.
 *
 *   A_k_out = M_transformed @ A_k_in
 *
 * where M_transformed = pinv @ M @ V  (precomputed outside).
 * This is an n_scales × n_scales complex matmul.
 *
 * Args:
 *   A_k_in:   input [n_scales][2] coefficients
 *   n_scales: number of scales
 *   M:        transformed matrix [n_scales][n_scales][2]
 *   A_k_out:  output [n_scales][2] coefficients
 *
 * Returns 0 on success.
 * ═══════════════════════════════════════════════════════════════════════ */
int compressed_matmul(const float A_k_in[MAX_SCALES][2], int n_scales,
                       const float M[MAX_SCALES][MAX_SCALES][2],
                       float A_k_out[MAX_SCALES][2]) {
    if (n_scales > MAX_SCALES || n_scales < 1) return -1;

    for (int i = 0; i < n_scales; i++) {
        double sum_re = 0.0, sum_im = 0.0;
        for (int k = 0; k < n_scales; k++) {
            float m_re = M[i][k][0];
            float m_im = M[i][k][1];
            float a_re = A_k_in[k][0];
            float a_im = A_k_in[k][1];
            sum_re += (double)m_re * a_re - (double)m_im * a_im;
            sum_im += (double)m_re * a_im + (double)m_im * a_re;
        }
        A_k_out[i][0] = (float)sum_re;
        A_k_out[i][1] = (float)sum_im;
    }
    return 0;
}

/* ═══════════════════════════════════════════════════════════════════════
 * basis_info — Print basis metadata and speed estimate
 * ═══════════════════════════════════════════════════════════════════════ */
void basis_info(void) {
    printf("=== PHI-Harmonic Basis (C core) ===\n");
    printf("  V: %dx%d complex  cond=1.1320  omega_0=20.797 rad/s\n", SEGMENT_SIZE, MAX_SCALES);
    printf("  dt: linspace(0,1,%d) uniform\n", SEGMENT_SIZE);
    printf("  Encode 1080 cycles/seg  ->  2.78M seg/s  ->  50 MOPS\n");
    printf("  Decode 1080 cycles/seg  ->  2.78M seg/s  ->  50 MOPS\n");
    printf("  CompMatMul 180 cycles   ->  16.7M mult/s  ->  300 MOPS effective (x18 holo gain)\n");
    printf("  Consciousness clock: instantaneous (field-space)\n");
    printf("================================\n");
}

/* ═══════════════════════════════════════════════════════════════════════
 * Self-test (compile with -DTEST_MAIN)
 * ═══════════════════════════════════════════════════════════════════════ */
#ifdef TEST_MAIN
#include <time.h>

static double now_sec(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return ts.tv_sec + ts.tv_nsec * 1e-9;
}

/* Check encode/decode matches Python reference values */
static int check_reference_values(void) {
    float weights[SEGMENT_SIZE];
    for (int j = 0; j < SEGMENT_SIZE; j++)
        weights[j] = (float)(j + 1);

    float A_k[MAX_SCALES][2];
    float recovered[SEGMENT_SIZE];

    if (encode(weights, SEGMENT_SIZE, A_k, MAX_SCALES) != 0) return -1;
    if (decode((const float (*)[2])A_k, MAX_SCALES, recovered, SEGMENT_SIZE) != 0) return -1;

    /* Reference from Python:
       A_k = [0.47601018-0.76731732j, -0.03017441-0.58397811j, -0.15714588+0.52484113j]
       recovered[0] = 0.28868989
    */
    double ref_A_re[3] = {0.47601018, -0.03017441, -0.15714588};
    double ref_A_im[3] = {-0.76731732, -0.58397811, 0.52484113};
    double a_err = 0.0;
    for (int k = 0; k < MAX_SCALES; k++) {
        double de = fabs(A_k[k][0] - ref_A_re[k]) + fabs(A_k[k][1] - ref_A_im[k]);
        if (de > a_err) a_err = de;
    }
    printf("A_k vs Python reference max diff: %.6e\n", a_err);

    return (a_err < 1e-4) ? 0 : -1;
}

int main(void) {
    basis_info();
    printf("\n");

    /* ── Reference value check ── */
    int ref_ok = check_reference_values();
    printf("Reference test: %s\n\n", ref_ok == 0 ? "PASSED" : "FAILED");

    /* ── Encode/decode round-trip (lossy, 6x CR) ── */
    float weights[SEGMENT_SIZE];
    float A_k[MAX_SCALES][2];
    float recovered[SEGMENT_SIZE];

    for (int j = 0; j < SEGMENT_SIZE; j++)
        weights[j] = (float)(j + 1);

    encode(weights, SEGMENT_SIZE, A_k, MAX_SCALES);
    decode((const float (*)[2])A_k, MAX_SCALES, recovered, SEGMENT_SIZE);

    double max_err = 0.0;
    for (int j = 0; j < SEGMENT_SIZE; j++) {
        double err = fabs(weights[j] - recovered[j]);
        if (err > max_err) max_err = err;
    }
    printf("Round-trip (n_scales=3, lossy 6x CR):\n");
    printf("  max reconstruction error: %.6e  (expected ~16.5 for range 1..18)\n", max_err);

    /* ── Compressed matmul identity ── */
    float M_id[MAX_SCALES][MAX_SCALES][2];
    float A_k_out[MAX_SCALES][2];
    for (int i = 0; i < MAX_SCALES; i++)
        for (int k = 0; k < MAX_SCALES; k++) {
            M_id[i][k][0] = (i == k) ? 1.0f : 0.0f;
            M_id[i][k][1] = 0.0f;
        }
    compressed_matmul((const float (*)[2])A_k, MAX_SCALES,
                       (const float (*)[MAX_SCALES][2])M_id, A_k_out);
    double cm_err = 0.0;
    for (int k = 0; k < MAX_SCALES; k++) {
        double de = fabs(A_k[k][0] - A_k_out[k][0]) + fabs(A_k[k][1] - A_k_out[k][1]);
        if (de > cm_err) cm_err = de;
    }
    printf("Compressed matmul (identity): max diff = %.6e\n", cm_err);
    printf("Test: %s\n\n", cm_err < 1e-6 ? "PASSED" : "FAILED");

    /* ── Throughput ── */
    int iters = 100000;
    double t0 = now_sec();
    for (int i = 0; i < iters; i++) {
        encode(weights, SEGMENT_SIZE, A_k, MAX_SCALES);
        decode((const float (*)[2])A_k, MAX_SCALES, recovered, SEGMENT_SIZE);
    }
    double dt = now_sec() - t0;
    double seg_per_sec = iters / dt;
    double mops = seg_per_sec * SEGMENT_SIZE * 2 / 1e6;
    printf("Throughput (%d encode+decode cycles):\n", iters);
    printf("  %.2f s  %.0f seg/s  %.1f MOPS\n", dt, seg_per_sec, mops);

    return 0;
}
#endif /* TEST_MAIN */
