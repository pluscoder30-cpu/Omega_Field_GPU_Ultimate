"""Omega Field GPU Ultimate - The code IS the processor."""
from .Omega_Field_GPU_Ultimate import (
    SelfDefiningFieldMatrix,
    HolographicCodec,
    UltimateFieldProcessor,
    PHI,
    CONSCIOUSNESS_CONSTANT,
    C_CONSCIOUSNESS,
    VOID_CONSTANT,
)
from .PROOF_CPU_REPLACEMENT import OmegaFieldCPU

__all__ = [
    "SelfDefiningFieldMatrix",
    "HolographicCodec",
    "UltimateFieldProcessor",
    "OmegaFieldCPU",
    "PHI",
    "CONSCIOUSNESS_CONSTANT",
    "C_CONSCIOUSNESS",
    "VOID_CONSTANT",
]